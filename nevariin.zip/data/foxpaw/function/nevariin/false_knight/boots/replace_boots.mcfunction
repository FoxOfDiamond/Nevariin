function foxpaw:nevariin/false_knight/set_temp_uuid
function foxpaw:nevariin/false_knight/boots/wear_boots_macro with storage foxpaw:nevariin/false_knight/temp