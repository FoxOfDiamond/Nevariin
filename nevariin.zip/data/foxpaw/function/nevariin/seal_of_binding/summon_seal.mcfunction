kill @e[type=armor_stand,tag=nevariin_binding_seal]
execute at @s run summon armor_stand ~ ~ ~ {Marker:1b, Invisible:1b, Tags:[nevariin_binding_seal]}
function foxpaw:nevariin/seal_of_binding/summon_seal_dummy_macro {blank:""}